<template>
    <div class="md:container md:mx-auto">
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7 pb-20">
            <div class="line_1">
                <div class="button_inform">
                    <button class="btn_back">Назад</button>
                    <p><span class="black_l1">Главная&ensp;/</span> &ensp;Позиции товара в выдаче</p>
                </div>
                <button class="btn_l1_right">Выгрузить отчет</button>
            </div>
            <h1 class="page_title">Позиция товара в выдаче</h1>
            <div class="line_2">
                <input type="text" placeholder="Введите артикул" class="l2_inp">
                <button class="btn_l2_add">Добавить</button>
                <button class="btn_l2_api">По API</button>
                <button class="btn_l2_mass">Массовое добавление</button>
            </div>
            <div class="line3_titles_table">
                <div class="l3_right">
                    <span class="l3_brand">Бренд</span>
                    <span class="l3_brand">Фото</span>
                    <span class="l3_brand">Артикул</span>
                    <span class="l3_brand">Цена</span>
                    <span class="l3_brand">Запрос</span>
                </div>
                <div class="l3_left">
                    <span class="l3_ch">Частотность WB</span>
                    <span class="l3_pr">Товаров на WB</span>
                    <span class="l3_5">5.07</span>
                    <span class="l3_6">6.07</span>
                    <span class="l3_5_1">5.07</span>
                    <span class="l3_6_1">6.07</span>
                    <span class="l3_5_2">5.07</span>
                    <span class="l3_6_2">6.07</span>
                </div>
            </div>
            <div class="table_string">
                <div class="str_left">
                    <img class="logo_brand" src="../../assets/images/logo_brand.svg" alt="">
                    <img class="product_img" src="../../assets/images/pr_img.svg" alt="">
                    <span class="table_art">y</span>
                    <span class="table_price">271 ₽</span>
                </div>
                <div class="table_request">
                    <div class="req">Футболка женская</div>
                    <div class="req">Футболка оверсайз</div>
                    <div class="req">Футболка</div>
                    <div class="req"><span class="req_p">Футболка женская оверсайз</span></div>
                    <div class="req">Футболка женская</div>
                </div>
                    <div class="col_stat">
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                    </div>
                    <div class="col_stat1">
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                    </div>
                    <div class="col_stat2">
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                        <span class="stat">150</span>
                    </div>
                    <div class="col_stat3">
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                    </div>
                    <div class="col_stat4">
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                    </div>
                    <div class="col_stat5">
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                    </div>
                    <div class="col_stat6">
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                        <span class="stat">77</span>
                    </div>
                    <div class="col_stat7">
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                        <span class="stat">78</span>
                    </div>
                <img class="arr_r" src="../../assets/images/arr_r.svg" alt="">
            </div>
            <div class="table_string">
                <div class="str_left">
                    <img class="logo_brand" src="../../assets/images/logo_brand.svg" alt="">
                    <img class="product_img" src="../../assets/images/pr_img.svg" alt="">
                    <span class="table_art">78858215</span>
                    <span class="table_price">271 ₽</span>
                </div>
                <div class="table_request">
                    <div class="req">Футболка женская</div>
                    <div class="req">Футболка оверсайз</div>
                    <div class="req">Футболка</div>
                    <div class="req"><span class="req_p">Футболка женская оверсайз</span></div>
                    <div class="req">Футболка женская</div>
                </div>
                <div class="col_stat">
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                </div>
                <div class="col_stat1">
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                </div>
                <div class="col_stat2">
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                </div>
                <div class="col_stat3">
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                </div>
                <div class="col_stat4">
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                </div>
                <div class="col_stat5">
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                </div>
                <div class="col_stat6">
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                </div>
                <div class="col_stat7">
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                </div>
                <img class="arr_r" src="../../assets/images/arr_r.svg" alt="">
            </div>
            <div class="table_string">
                <div class="str_left">
                    <img class="logo_brand" src="../../assets/images/logo_brand.svg" alt="">
                    <img class="product_img" src="../../assets/images/pr_img.svg" alt="">
                    <span class="table_art">78858215</span>
                    <span class="table_price">271 ₽</span>
                </div>
                <div class="table_request">
                    <div class="req">Футболка женская</div>
                    <div class="req">Футболка оверсайз</div>
                    <div class="req">Футболка</div>
                    <div class="req"><span class="req_p">Футболка женская оверсайз</span></div>
                    <div class="req">Футболка женская</div>
                </div>
                <div class="col_stat">
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                </div>
                <div class="col_stat1">
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                </div>
                <div class="col_stat2">
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                    <span class="stat">150</span>
                </div>
                <div class="col_stat3">
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                </div>
                <div class="col_stat4">
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                </div>
                <div class="col_stat5">
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                </div>
                <div class="col_stat6">
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                    <span class="stat">77</span>
                </div>
                <div class="col_stat7">
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                    <span class="stat">78</span>
                </div>
                <img class="arr_r" src="../../assets/images/arr_r.svg" alt="">
            </div>
            <div class="table_string">
                <div class="str_left">
                    <img class="logo_brand" src="../../assets/images/logo_brand.svg" alt="">
                    <img class="product_img" src="../../assets/images/pr_img.svg" alt="">
                    <span class="table_art">78858215</span>
                    <span class="table_price">271 ₽</span>
                </div>
                <div class="err_r">
                    <h1 class="err_title">Недоступно.Тариф не оплачен</h1>
                    <p class="err_txt">К сожалению, деньги на балансе закончились и доcтуп к функционалу сервиса ограничен бесплатным тарифом. Вы можете пополнить баланс и продолжать пользоваться возможностями сервиса
                    </p>
                    <button class="btn_l2_add">Пополнить</button>
                </div>
            </div>

        </div>
    </div>
</template>

<style scoped>
.stat {
  height: 35px;
  text-align: center;
  display: flex;
  justify-content: center;
  align-items: center;

  font-size: 15px;
  font-weight: 500;
}
</style>