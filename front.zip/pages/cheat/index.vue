<template>
    <div class="md:container md:mx-auto">
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7">
            <div class="md:grid md:grid-cols-2">
                <div class="">
                    <div class="content-title">Лайки на товар / бренд</div>
                    <div class="content-desc mt-3.5">Выберете товар или бренд, чтобы повысить количество добавлений в
                        «Избранное»</div>
                </div>
                <div class="md:flex md:gap-2.5 md:items-center md:justify-end mt-2.5 md:mt-0">
                    <div><nuxt-link to="cheat/cheat_1" class="but but_1 p-1.5">Заказать</nuxt-link></div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7">
            <div class="md:grid md:grid-cols-2">
                <div class="">
                    <div class="content-title">Вопросы</div>
                    <div class="content-desc mt-3.5">Выберете товар или бренд, чтобы добавить конкретные вопросы к нему
                    </div>
                </div>
                <div class="md:flex md:gap-2.5 md:items-center md:justify-end mt-2.5 md:mt-0">
                    <div><nuxt-link to="cheat/cheat_2" class="but but_1 p-1.5">Заказать</nuxt-link></div>
                </div>
            </div>
        </div>
        <div class="bg-white rounded-3xl mt-2.5 mx-2.5 p-7">
            <div class="md:grid md:grid-cols-2">
                <div class="">
                    <div class="content-title">Лайки на отзывы</div>
                    <div class="content-desc mt-3.5">Лайки на отзывах, помогут вашим покупателям обратить внимание
                        только на самые важные отзывы.</div>
                </div>
                <div class="md:flex md:gap-2.5 md:items-center md:justify-end mt-2.5 md:mt-0">
                    <div><nuxt-link to="cheat/cheat_3" class="but but_1 p-1.5">Заказать</nuxt-link></div>
                </div>
            </div>
        </div>
    </div>
</template>