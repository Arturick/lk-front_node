<template>
    <div class="md:container md:mx-auto">
        <div class="md:px-2.5 md:py-7 px-2.5 py-4">
        </div>
    </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      
    }
  },
}
</script>

<style scoped>

</style>