export default () => ({
  user: {},
  opt_roles: [],
  timeIsOut: 0
})
