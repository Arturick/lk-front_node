export default {
  SET_USER(state, user) {
    state.user = user
  },
  SET_OPT_ROLES(state, opt_roles) {
    state.opt_roles = opt_roles
  },
  SET_TIMEISOUT(state, timeIsOut) {
    state.timeIsOut = timeIsOut
  },
  
}
