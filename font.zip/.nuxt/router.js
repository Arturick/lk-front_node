import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _5ac5eecd = () => interopDefault(import('..\\pages\\buyout\\index.vue' /* webpackChunkName: "pages/buyout/index" */))
const _38c353a1 = () => interopDefault(import('..\\pages\\delivery\\index.vue' /* webpackChunkName: "pages/delivery/index" */))
const _6be30580 = () => interopDefault(import('..\\pages\\reports\\index.vue' /* webpackChunkName: "pages/reports/index" */))
const _4b9b0964 = () => interopDefault(import('..\\pages\\reviews\\index.vue' /* webpackChunkName: "pages/reviews/index" */))
const _6bed54ea = () => interopDefault(import('..\\pages\\user\\index.vue' /* webpackChunkName: "pages/user/index" */))
const _7db66378 = () => interopDefault(import('..\\pages\\buyout\\plan\\index.vue' /* webpackChunkName: "pages/buyout/plan/index" */))
const _24d01bb8 = () => interopDefault(import('..\\pages\\reports\\buyout\\index.vue' /* webpackChunkName: "pages/reports/buyout/index" */))
const _f95fa5d6 = () => interopDefault(import('..\\pages\\reports\\comment\\index.vue' /* webpackChunkName: "pages/reports/comment/index" */))
const _3594f801 = () => interopDefault(import('..\\pages\\user\\login.vue' /* webpackChunkName: "pages/user/login" */))
const _ef2dc904 = () => interopDefault(import('..\\pages\\buyout\\plan\\_group.vue' /* webpackChunkName: "pages/buyout/plan/_group" */))
const _049b41c1 = () => interopDefault(import('..\\pages\\delivery\\_group.vue' /* webpackChunkName: "pages/delivery/_group" */))
const _4cba445e = () => interopDefault(import('..\\pages\\reviews\\_group.vue' /* webpackChunkName: "pages/reviews/_group" */))
const _369f3555 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/buyout",
    component: _5ac5eecd,
    name: "buyout"
  }, {
    path: "/delivery",
    component: _38c353a1,
    name: "delivery"
  }, {
    path: "/reports",
    component: _6be30580,
    name: "reports"
  }, {
    path: "/reviews",
    component: _4b9b0964,
    name: "reviews"
  }, {
    path: "/user",
    component: _6bed54ea,
    name: "user"
  }, {
    path: "/buyout/plan",
    component: _7db66378,
    name: "buyout-plan"
  }, {
    path: "/reports/buyout",
    component: _24d01bb8,
    name: "reports-buyout"
  }, {
    path: "/reports/comment",
    component: _f95fa5d6,
    name: "reports-comment"
  }, {
    path: "/user/login",
    component: _3594f801,
    name: "user-login"
  }, {
    path: "/buyout/plan/:group",
    component: _ef2dc904,
    name: "buyout-plan-group"
  }, {
    path: "/delivery/:group",
    component: _049b41c1,
    name: "delivery-group"
  }, {
    path: "/reviews/:group",
    component: _4cba445e,
    name: "reviews-group"
  }, {
    path: "/",
    component: _369f3555,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
