<template>
	<v-app >
		<div class="rate-app">
			<TheHeader />
			<Nuxt />
			<TheFooter />
		</div>
	</v-app>
</template>
